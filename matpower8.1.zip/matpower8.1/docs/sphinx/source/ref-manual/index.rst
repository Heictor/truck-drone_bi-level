.. _matpower_ref_manual:

###########################
|MATPOWER| Reference Manual
###########################

.. only:: html

   .. image:: ../MATPOWER-md.png

   [ :download:`PDF format <../../build/latex/matpower_ref_manual.pdf>` ]

.. toctree::
   :numbered: 2

   introduction
   functions/index
   classes/index
   tests/index
   legacy/index
   previous
